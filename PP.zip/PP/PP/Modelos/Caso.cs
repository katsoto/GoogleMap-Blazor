﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace PP.Modelos
{
    public partial class Caso
    {
        public int Id { get; set; }
        public int? Cedula { get; set; }
        public string Nombre { get; set; }

        public DateTime? Fecha { get; set; }
        public string Robo { get; set; }
        public double? Valor { get; set; }
        public string Sitio { get; set; }
        public string Latitud { get; set; }
        public string Longitud { get; set; }
    }
}
